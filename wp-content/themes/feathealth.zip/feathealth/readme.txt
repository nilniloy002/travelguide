Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/feathealth/
Buy theme: http://smthemes.com/buy/feathealth/
Support Forums: http://smthemes.com/support/forum/feathealth-free-wordpress-theme/