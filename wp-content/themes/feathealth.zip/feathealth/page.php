<?php 
	global $SMTheme;
?>
			
			<?php get_header(); ?>
			
			<?php get_template_part('theloop'); ?>

			<?php get_footer(); ?>